# Install the Codex Skills Suite

From the repository root, copy the bundled skills into your Codex skills directory:

~~~bash
mkdir -p "$HOME/.codex/skills"
cp -R skills/* "$HOME/.codex/skills/"
~~~

The optional shared agent instructions are in agents/AGENTS.md. Review them and copy them only to the project or Codex configuration location used by your setup.

This public bundle excludes the proprietary keyword scraper and its standalone skill. Use user-provided keyword data or an explicitly approved research source.
